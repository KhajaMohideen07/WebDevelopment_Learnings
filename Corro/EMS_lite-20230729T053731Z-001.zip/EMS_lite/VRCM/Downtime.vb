﻿Public Class Downtime

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Downtime_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class