﻿Imports System
Imports Microsoft.Win32
Imports System.Windows.Forms
Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class Form2


    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'lod_conection()
    End Sub
End Class