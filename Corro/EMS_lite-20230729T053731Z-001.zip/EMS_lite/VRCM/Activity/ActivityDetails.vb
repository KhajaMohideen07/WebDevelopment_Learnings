﻿Public Class ActivityDetails

End Class