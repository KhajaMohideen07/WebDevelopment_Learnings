﻿Public Class production_Update

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click, Label4.Click, Label5.Click

    End Sub

    Private Sub production_Update_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class