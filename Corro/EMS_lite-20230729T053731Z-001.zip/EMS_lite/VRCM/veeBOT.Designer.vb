﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class veeBOT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(veeBOT))
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.LaunchDashboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutValidationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActivityPlannerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActivityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AssignToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NULLUpdaterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HeadcountUploadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewActivityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VMessageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BreakAdjustmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReleaseKeyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TLAccessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbl_lock = New System.Windows.Forms.Label()
        Me.sbar_ist = New System.Windows.Forms.Label()
        Me.sec_refresh = New System.Windows.Forms.Timer(Me.components)
        Me.App_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.NullAppUpdater = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.auto_signout = New System.Windows.Forms.Timer(Me.components)
        Me.Remainder = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DBTime = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.NotifyIcon1.Text = "vBOT"
        Me.NotifyIcon1.Visible = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaunchDashboardToolStripMenuItem, Me.LogoutValidationToolStripMenuItem, Me.ActivityPlannerToolStripMenuItem, Me.ActivityToolStripMenuItem, Me.NULLUpdaterToolStripMenuItem, Me.HeadcountUploadToolStripMenuItem, Me.ToolStripMenuItem1, Me.ViewActivityToolStripMenuItem, Me.VMessageToolStripMenuItem, Me.BreakAdjustmentToolStripMenuItem, Me.ReportingToolStripMenuItem, Me.ToolStripMenuItem2, Me.ReleaseKeyToolStripMenuItem, Me.RestartToolStripMenuItem, Me.TLAccessToolStripMenuItem, Me.LogOffToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(175, 356)
        '
        'LaunchDashboardToolStripMenuItem
        '
        Me.LaunchDashboardToolStripMenuItem.Name = "LaunchDashboardToolStripMenuItem"
        Me.LaunchDashboardToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.LaunchDashboardToolStripMenuItem.Text = "Launch Dashboard"
        '
        'LogoutValidationToolStripMenuItem
        '
        Me.LogoutValidationToolStripMenuItem.Name = "LogoutValidationToolStripMenuItem"
        Me.LogoutValidationToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.LogoutValidationToolStripMenuItem.Text = "Logout Validation"
        Me.LogoutValidationToolStripMenuItem.Visible = False
        '
        'ActivityPlannerToolStripMenuItem
        '
        Me.ActivityPlannerToolStripMenuItem.Name = "ActivityPlannerToolStripMenuItem"
        Me.ActivityPlannerToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.ActivityPlannerToolStripMenuItem.Text = "Activity Planner"
        Me.ActivityPlannerToolStripMenuItem.Visible = False
        '
        'ActivityToolStripMenuItem
        '
        Me.ActivityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManageToolStripMenuItem, Me.AssignToolStripMenuItem, Me.UpdateToolStripMenuItem})
        Me.ActivityToolStripMenuItem.Name = "ActivityToolStripMenuItem"
        Me.ActivityToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.ActivityToolStripMenuItem.Text = "Activity"
        Me.ActivityToolStripMenuItem.Visible = False
        '
        'ManageToolStripMenuItem
        '
        Me.ManageToolStripMenuItem.Name = "ManageToolStripMenuItem"
        Me.ManageToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ManageToolStripMenuItem.Text = "Manage"
        '
        'AssignToolStripMenuItem
        '
        Me.AssignToolStripMenuItem.Name = "AssignToolStripMenuItem"
        Me.AssignToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.AssignToolStripMenuItem.Text = "Assign"
        '
        'UpdateToolStripMenuItem
        '
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        Me.UpdateToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.UpdateToolStripMenuItem.Text = "Update"
        '
        'NULLUpdaterToolStripMenuItem
        '
        Me.NULLUpdaterToolStripMenuItem.Name = "NULLUpdaterToolStripMenuItem"
        Me.NULLUpdaterToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.NULLUpdaterToolStripMenuItem.Text = "NULL Updater"
        Me.NULLUpdaterToolStripMenuItem.Visible = False
        '
        'HeadcountUploadToolStripMenuItem
        '
        Me.HeadcountUploadToolStripMenuItem.Name = "HeadcountUploadToolStripMenuItem"
        Me.HeadcountUploadToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.HeadcountUploadToolStripMenuItem.Text = "Headcount Upload"
        Me.HeadcountUploadToolStripMenuItem.Visible = False
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Image = Global.VRCM.My.Resources.Resources.no_photo
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(174, 22)
        Me.ToolStripMenuItem1.Text = "User Details"
        Me.ToolStripMenuItem1.Visible = False
        '
        'ViewActivityToolStripMenuItem
        '
        Me.ViewActivityToolStripMenuItem.Image = CType(resources.GetObject("ViewActivityToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewActivityToolStripMenuItem.Name = "ViewActivityToolStripMenuItem"
        Me.ViewActivityToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.ViewActivityToolStripMenuItem.Text = "View Activity"
        Me.ViewActivityToolStripMenuItem.Visible = False
        '
        'VMessageToolStripMenuItem
        '
        Me.VMessageToolStripMenuItem.Image = Global.VRCM.My.Resources.Resources.messenger
        Me.VMessageToolStripMenuItem.Name = "VMessageToolStripMenuItem"
        Me.VMessageToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.VMessageToolStripMenuItem.Text = "Message"
        Me.VMessageToolStripMenuItem.Visible = False
        '
        'BreakAdjustmentToolStripMenuItem
        '
        Me.BreakAdjustmentToolStripMenuItem.Name = "BreakAdjustmentToolStripMenuItem"
        Me.BreakAdjustmentToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.BreakAdjustmentToolStripMenuItem.Text = "Break Adjustment"
        Me.BreakAdjustmentToolStripMenuItem.Visible = False
        '
        'ReportingToolStripMenuItem
        '
        Me.ReportingToolStripMenuItem.Name = "ReportingToolStripMenuItem"
        Me.ReportingToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.ReportingToolStripMenuItem.Text = "Reporting"
        Me.ReportingToolStripMenuItem.Visible = False
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(174, 22)
        Me.ToolStripMenuItem2.Text = "Resignation"
        Me.ToolStripMenuItem2.Visible = False
        '
        'ReleaseKeyToolStripMenuItem
        '
        Me.ReleaseKeyToolStripMenuItem.Name = "ReleaseKeyToolStripMenuItem"
        Me.ReleaseKeyToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.ReleaseKeyToolStripMenuItem.Text = "ReleaseKey"
        Me.ReleaseKeyToolStripMenuItem.Visible = False
        '
        'RestartToolStripMenuItem
        '
        Me.RestartToolStripMenuItem.Name = "RestartToolStripMenuItem"
        Me.RestartToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.RestartToolStripMenuItem.Text = "Restart"
        '
        'TLAccessToolStripMenuItem
        '
        Me.TLAccessToolStripMenuItem.Name = "TLAccessToolStripMenuItem"
        Me.TLAccessToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.TLAccessToolStripMenuItem.Text = "TL Access"
        Me.TLAccessToolStripMenuItem.Visible = False
        '
        'LogOffToolStripMenuItem
        '
        Me.LogOffToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogOffToolStripMenuItem.Image = Global.VRCM.My.Resources.Resources.logout
        Me.LogOffToolStripMenuItem.Name = "LogOffToolStripMenuItem"
        Me.LogOffToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.LogOffToolStripMenuItem.Text = "LOGOUT"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'lbl_lock
        '
        Me.lbl_lock.AutoSize = True
        Me.lbl_lock.Location = New System.Drawing.Point(112, 78)
        Me.lbl_lock.Name = "lbl_lock"
        Me.lbl_lock.Size = New System.Drawing.Size(19, 13)
        Me.lbl_lock.TabIndex = 0
        Me.lbl_lock.Text = "20"
        '
        'sbar_ist
        '
        Me.sbar_ist.AutoSize = True
        Me.sbar_ist.BackColor = System.Drawing.Color.Transparent
        Me.sbar_ist.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sbar_ist.ForeColor = System.Drawing.Color.Black
        Me.sbar_ist.Location = New System.Drawing.Point(39, 84)
        Me.sbar_ist.Name = "sbar_ist"
        Me.sbar_ist.Size = New System.Drawing.Size(57, 13)
        Me.sbar_ist.TabIndex = 2
        Me.sbar_ist.Text = "00:00:00"
        '
        'sec_refresh
        '
        Me.sec_refresh.Interval = 1000
        '
        'App_Timer
        '
        Me.App_Timer.Interval = 1000
        '
        'NullAppUpdater
        '
        Me.NullAppUpdater.Interval = 5000
        '
        'Timer2
        '
        Me.Timer2.Interval = 60000
        '
        'auto_signout
        '
        Me.auto_signout.Enabled = True
        Me.auto_signout.Interval = 7200000
        '
        'Remainder
        '
        Me.Remainder.Interval = 60000
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        Me.Timer4.Interval = 900000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Label1"
        '
        'DBTime
        '
        Me.DBTime.Interval = 1000
        '
        'veeBOT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BackgroundImage = Global.VRCM.My.Resources.Resources.veeBot
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(133, 100)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.sbar_ist)
        Me.Controls.Add(Me.lbl_lock)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "veeBOT"
        Me.Opacity = 0.0R
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lbl_lock As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents LogOffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VMessageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents sbar_ist As System.Windows.Forms.Label
    Friend WithEvents sec_refresh As System.Windows.Forms.Timer
    Friend WithEvents App_Timer As System.Windows.Forms.Timer
    Friend WithEvents ViewActivityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NullAppUpdater As System.Windows.Forms.Timer
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutValidationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NULLUpdaterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaunchDashboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents auto_signout As System.Windows.Forms.Timer
    Friend WithEvents ActivityPlannerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActivityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ManageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AssignToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HeadcountUploadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BreakAdjustmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReleaseKeyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Remainder As System.Windows.Forms.Timer
    Friend WithEvents TLAccessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DBTime As System.Windows.Forms.Timer
End Class
