﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User_Details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbDepartment = New System.Windows.Forms.ComboBox()
        Me.cbDesignation = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbProjectClass = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbAccessRole = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbLocation = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbProject = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cbCostCenter = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cbReporting1 = New System.Windows.Forms.ComboBox()
        Me.cbReporting2 = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.dtpShiftIn = New System.Windows.Forms.DateTimePicker()
        Me.dtpShiftOut = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbFirstName = New System.Windows.Forms.TextBox()
        Me.tbLastName = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dtpDOJ = New System.Windows.Forms.DateTimePicker()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "VRCM ID"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(103, 24)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Department"
        '
        'cbDepartment
        '
        Me.cbDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDepartment.FormattingEnabled = True
        Me.cbDepartment.Location = New System.Drawing.Point(140, 130)
        Me.cbDepartment.Name = "cbDepartment"
        Me.cbDepartment.Size = New System.Drawing.Size(219, 21)
        Me.cbDepartment.TabIndex = 1
        '
        'cbDesignation
        '
        Me.cbDesignation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDesignation.FormattingEnabled = True
        Me.cbDesignation.Location = New System.Drawing.Point(140, 157)
        Me.cbDesignation.Name = "cbDesignation"
        Me.cbDesignation.Size = New System.Drawing.Size(219, 21)
        Me.cbDesignation.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 160)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Designation"
        '
        'cbProjectClass
        '
        Me.cbProjectClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbProjectClass.FormattingEnabled = True
        Me.cbProjectClass.Location = New System.Drawing.Point(140, 211)
        Me.cbProjectClass.Name = "cbProjectClass"
        Me.cbProjectClass.Size = New System.Drawing.Size(219, 21)
        Me.cbProjectClass.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(28, 214)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Project Classification"
        '
        'cbAccessRole
        '
        Me.cbAccessRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbAccessRole.FormattingEnabled = True
        Me.cbAccessRole.Location = New System.Drawing.Point(140, 238)
        Me.cbAccessRole.Name = "cbAccessRole"
        Me.cbAccessRole.Size = New System.Drawing.Size(219, 21)
        Me.cbAccessRole.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(28, 241)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Access Role"
        '
        'cbLocation
        '
        Me.cbLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbLocation.FormattingEnabled = True
        Me.cbLocation.Location = New System.Drawing.Point(140, 265)
        Me.cbLocation.Name = "cbLocation"
        Me.cbLocation.Size = New System.Drawing.Size(219, 21)
        Me.cbLocation.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(28, 268)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Location"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(28, 187)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Project"
        '
        'cbProject
        '
        Me.cbProject.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbProject.FormattingEnabled = True
        Me.cbProject.Location = New System.Drawing.Point(140, 184)
        Me.cbProject.Name = "cbProject"
        Me.cbProject.Size = New System.Drawing.Size(219, 21)
        Me.cbProject.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(28, 295)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Cost Center"
        '
        'cbCostCenter
        '
        Me.cbCostCenter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCostCenter.FormattingEnabled = True
        Me.cbCostCenter.Location = New System.Drawing.Point(140, 292)
        Me.cbCostCenter.Name = "cbCostCenter"
        Me.cbCostCenter.Size = New System.Drawing.Size(219, 21)
        Me.cbCostCenter.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(28, 322)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(62, 13)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Reporting 1"
        '
        'cbReporting1
        '
        Me.cbReporting1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbReporting1.FormattingEnabled = True
        Me.cbReporting1.Location = New System.Drawing.Point(140, 319)
        Me.cbReporting1.Name = "cbReporting1"
        Me.cbReporting1.Size = New System.Drawing.Size(219, 21)
        Me.cbReporting1.TabIndex = 8
        '
        'cbReporting2
        '
        Me.cbReporting2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbReporting2.FormattingEnabled = True
        Me.cbReporting2.Location = New System.Drawing.Point(140, 346)
        Me.cbReporting2.Name = "cbReporting2"
        Me.cbReporting2.Size = New System.Drawing.Size(219, 21)
        Me.cbReporting2.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(28, 349)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(62, 13)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Reporting 2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(28, 376)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(40, 13)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Shift In"
        '
        'dtpShiftIn
        '
        Me.dtpShiftIn.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpShiftIn.Location = New System.Drawing.Point(140, 373)
        Me.dtpShiftIn.Name = "dtpShiftIn"
        Me.dtpShiftIn.Size = New System.Drawing.Size(72, 20)
        Me.dtpShiftIn.TabIndex = 15
        Me.dtpShiftIn.Value = New Date(2019, 3, 7, 0, 0, 0, 0)
        '
        'dtpShiftOut
        '
        Me.dtpShiftOut.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpShiftOut.Location = New System.Drawing.Point(287, 373)
        Me.dtpShiftOut.Name = "dtpShiftOut"
        Me.dtpShiftOut.Size = New System.Drawing.Size(72, 20)
        Me.dtpShiftOut.TabIndex = 15
        Me.dtpShiftOut.Value = New Date(2019, 3, 7, 0, 0, 0, 0)
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(232, 376)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(48, 13)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "Shift Out"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(222, 22)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Edit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(28, 81)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(57, 13)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "First Name"
        '
        'tbFirstName
        '
        Me.tbFirstName.Location = New System.Drawing.Point(140, 78)
        Me.tbFirstName.Name = "tbFirstName"
        Me.tbFirstName.Size = New System.Drawing.Size(219, 20)
        Me.tbFirstName.TabIndex = 19
        '
        'tbLastName
        '
        Me.tbLastName.Location = New System.Drawing.Point(140, 104)
        Me.tbLastName.Name = "tbLastName"
        Me.tbLastName.Size = New System.Drawing.Size(219, 20)
        Me.tbLastName.TabIndex = 21
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(28, 107)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(58, 13)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Last Name"
        '
        'dtpDOB
        '
        Me.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDOB.Location = New System.Drawing.Point(418, 78)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.Size = New System.Drawing.Size(88, 20)
        Me.dtpDOB.TabIndex = 24
        Me.dtpDOB.Value = New Date(2019, 3, 7, 0, 0, 0, 0)
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(382, 81)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(30, 13)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "DOB"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(382, 107)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 13)
        Me.Label15.TabIndex = 22
        Me.Label15.Text = "DOJ"
        '
        'dtpDOJ
        '
        Me.dtpDOJ.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDOJ.Location = New System.Drawing.Point(418, 104)
        Me.dtpDOJ.Name = "dtpDOJ"
        Me.dtpDOJ.Size = New System.Drawing.Size(88, 20)
        Me.dtpDOJ.TabIndex = 24
        Me.dtpDOJ.Value = New Date(2019, 3, 7, 0, 0, 0, 0)
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.DataGridView1.Location = New System.Drawing.Point(512, 53)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(664, 457)
        Me.DataGridView1.TabIndex = 25
        '
        'Column1
        '
        Me.Column1.HeaderText = "emp_id"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "login_date"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "start_time"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.HeaderText = "end_time"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "app_name"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(510, 24)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 26
        Me.Button2.Text = "Get"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'User_Details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1211, 668)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.dtpDOJ)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.dtpDOB)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.tbLastName)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.tbFirstName)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.dtpShiftOut)
        Me.Controls.Add(Me.dtpShiftIn)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.cbReporting2)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cbLocation)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cbAccessRole)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cbProject)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cbReporting1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cbCostCenter)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cbProjectClass)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cbDesignation)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbDepartment)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "User_Details"
        Me.Text = "User_Details"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbDepartment As System.Windows.Forms.ComboBox
    Friend WithEvents cbDesignation As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cbProjectClass As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cbAccessRole As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cbLocation As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbProject As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cbCostCenter As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cbReporting1 As System.Windows.Forms.ComboBox
    Friend WithEvents cbReporting2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents dtpShiftIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpShiftOut As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tbFirstName As System.Windows.Forms.TextBox
    Friend WithEvents tbLastName As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents dtpDOJ As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
